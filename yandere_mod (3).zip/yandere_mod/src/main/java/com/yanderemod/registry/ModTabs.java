package com.yanderemod.registry;

import com.yanderemod.YandereMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, YandereMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("creativetab.yandere_mod"))
                    .icon(() -> new ItemStack(ModItems.LOVE_LETTER.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.LOVE_LETTER.get());
                        out.accept(ModItems.YANDERE_KNIFE.get());
                        out.accept(ModItems.YANDERE_SPAWN_EGG.get());
                    })
                    .build());
}
