package com.yanderemod.registry;

import com.yanderemod.YandereMod;
import com.yanderemod.item.LoveLetterItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, YandereMod.MODID);

    public static final RegistryObject<Item> LOVE_LETTER = ITEMS.register("love_letter",
            () -> new LoveLetterItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> YANDERE_KNIFE = ITEMS.register("yandere_knife",
            () -> new SwordItem(Tiers.IRON, 2, -1.6F, new Item.Properties()));

    public static final RegistryObject<Item> YANDERE_SPAWN_EGG = ITEMS.register("yandere_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.YANDERE, 0xF48FB1, 0x8B0000, new Item.Properties()));
}
