package com.yanderemod.entity;

import com.yanderemod.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;

public class YandereEntity extends PathfinderMob {
    private static final EntityDataAccessor<Optional<UUID>> OBSESSION =
            SynchedEntityData.defineId(YandereEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    public YandereEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OBSESSION, Optional.empty());
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(2, new FollowObsessionGoal(this, 1.1D));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));

        // Помста тому, хто її вдарив
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // Ревнощі: будь-який інший гравець поруч з обраним
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, target -> {
            Player owner = getObsession();
            return owner != null && target != owner && target instanceof Player p
                    && !p.isCreative() && !p.isSpectator() && p.distanceToSqr(owner) < 64.0D;
        }));
        // Захист обраного від мобів
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Mob.class, 10, true, false, target -> {
            Player owner = getObsession();
            return owner != null && target instanceof Mob m && m != this && m.getTarget() == owner;
        }));
    }

    // ---------- Одержимість ----------

    @Nullable
    public Player getObsession() {
        UUID id = this.entityData.get(OBSESSION).orElse(null);
        return id == null ? null : this.level().getPlayerByUUID(id);
    }

    public boolean isObsessed() {
        return this.entityData.get(OBSESSION).isPresent();
    }

    public void setObsession(@Nullable Player player) {
        this.entityData.set(OBSESSION, Optional.ofNullable(player == null ? null : player.getUUID()));
        if (player != null) {
            this.setPersistenceRequired();
            this.setTarget(null);
            if (this.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.8D, getZ(), 8, 0.4D, 0.4D, 0.4D, 0.02D);
            }
            say(player, "message.yandere_mod.love");
        }
    }

    private void say(Player player, String key) {
        player.sendSystemMessage(Component.translatable("message.yandere_mod.format",
                this.getName(), Component.translatable(key)));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            // Візуальні ефекти під стан: сердечка (закохана) / злість (агресія)
            if (this.isAggressive()) {
                if (this.random.nextInt(15) == 0) {
                    this.level().addParticle(ParticleTypes.ANGRY_VILLAGER,
                            this.getRandomX(0.5D), this.getY() + 2.0D, this.getRandomZ(0.5D), 0.0D, 0.0D, 0.0D);
                }
            } else if (this.isObsessed() && this.random.nextInt(25) == 0) {
                this.level().addParticle(ParticleTypes.HEART,
                        this.getRandomX(0.6D), this.getY() + 1.9D, this.getRandomZ(0.6D), 0.0D, 0.04D, 0.0D);
            }
        }
        if (!this.level().isClientSide && this.tickCount % 20 == 0) {
            Player owner = getObsession();
            if (owner != null) {
                if (this.random.nextInt(90) == 0) {
                    say(owner, "message.yandere_mod.line" + (1 + this.random.nextInt(5)));
                }
                if (this.random.nextInt(300) == 0) {
                    this.spawnAtLocation(Items.POPPY); // «подарунок»
                }
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && source.getEntity() instanceof Player p) {
            UUID id = this.entityData.get(OBSESSION).orElse(null);
            if (p.getUUID().equals(id)) {
                this.entityData.set(OBSESSION, Optional.empty());
                say(p, "message.yandere_mod.betrayed");
            }
        }
        return super.hurt(source, amount);
    }

    // ---------- Спавн, звуки, NBT ----------

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.YANDERE_KNIFE.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        this.setLeftHanded(false); // анімації моделі розраховані на ніж у правій руці
        return result;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        this.entityData.get(OBSESSION).ifPresent(id -> tag.putUUID("Obsession", id));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Obsession")) {
            this.entityData.set(OBSESSION, Optional.of(tag.getUUID("Obsession")));
        }
    }

    // ---------- Ціль: ходити за обраним ----------

    static class FollowObsessionGoal extends Goal {
        private final YandereEntity mob;
        private final double speed;
        private Player owner;
        private int recalc;

        FollowObsessionGoal(YandereEntity mob, double speed) {
            this.mob = mob;
            this.speed = speed;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            this.owner = mob.getObsession();
            return owner != null && owner.isAlive() && !owner.isSpectator()
                    && mob.getTarget() == null && mob.distanceToSqr(owner) > 9.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && mob.getTarget() == null
                    && mob.distanceToSqr(owner) > 4.0D;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            owner = null;
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            mob.getLookControl().setLookAt(owner, 10.0F, (float) mob.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (mob.distanceToSqr(owner) > 400.0D) { // далі 20 блоків — «телепорт до коханого»
                    mob.moveTo(owner.getX() + 1.5D, owner.getY(), owner.getZ() + 1.5D, mob.getYRot(), mob.getXRot());
                    mob.getNavigation().stop();
                } else {
                    mob.getNavigation().moveTo(owner, speed);
                }
            }
        }
    }
}
